package JavaPrograms;
import java.util.*;
public class pgm3 {

	public static void main(String[] args) {
		Scanner i = new Scanner(System.in);
		int a = i.nextInt();
		if(a%2==0)
		{
			System.out.print(a + " is Even");
		}
		else 
		{
			System.out.print(a + " is Odd");
		}

	}

}
